extern int c_add(int, int);
#define C_TEN 10
