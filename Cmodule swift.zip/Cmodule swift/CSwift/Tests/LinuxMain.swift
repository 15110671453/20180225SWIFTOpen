import XCTest
@testable import CSwiftTests

XCTMain([
     testCase(CSwiftTests.allTests),
])
